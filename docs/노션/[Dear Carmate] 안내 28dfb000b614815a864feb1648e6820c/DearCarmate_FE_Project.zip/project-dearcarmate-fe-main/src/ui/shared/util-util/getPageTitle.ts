const getPageTitle = (text: string) => {
  return `${text} : Dear Carmate`
}

export default getPageTitle
