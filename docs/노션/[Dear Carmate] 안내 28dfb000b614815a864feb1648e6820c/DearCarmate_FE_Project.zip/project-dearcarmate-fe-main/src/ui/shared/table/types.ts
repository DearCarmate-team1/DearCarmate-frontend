export type Column<R> = {
  key: keyof R
  title: string
}
