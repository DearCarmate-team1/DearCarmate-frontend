export const PAGES_PER_PAGINATION = 8

export const CARS_PAGE_SIZE = 8
export const CUSTOMERS_PAGE_SIZE = 8
export const CONTRACT_DRAFTS_PAGE_SIZE = 8
export const COMPANIES_PAGE_SIZE = 8
export const USERS_PAGE_SIZE = 8
export const CONTRACT_DOCUMENTS_PAGE_SIZE = 8
