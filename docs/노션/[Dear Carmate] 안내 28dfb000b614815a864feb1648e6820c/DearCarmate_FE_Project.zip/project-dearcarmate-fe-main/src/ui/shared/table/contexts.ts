import { createContext } from 'react'

export const TableHeadContext = createContext(false)
export const TableBodyContext = createContext(false)
