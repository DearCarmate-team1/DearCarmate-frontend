export const CAR_LABELS = [
  '경·소형',
  '준중·중형',
  '대형',
  '스포츠카',
  'SUV',
]
